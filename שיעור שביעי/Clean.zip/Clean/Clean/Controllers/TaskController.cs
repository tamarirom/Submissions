﻿using Microsoft.AspNetCore.Mvc;
using Clean.Service;
using Clean.Core.Entities;
using Task = Clean.Core.Entities.Task;
using Clean.Core.Services;

namespace Clean.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITaskService _taskService;

        public TaskController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        // GET: api/<TaskController>
        [HttpGet]
        public IEnumerable<Task> Get()
        {
            return _taskService.GetAll();
        }

        // GET api/<TaskController>/5
        [HttpGet("{id}")]
        public Task Get(int id)
        {
            return _taskService.GetById(id);
        }

        // POST api/<TaskController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<TaskController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<TaskController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
