﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Task = Clean.Core.Entities.Task;
using Clean.Core.Repositories;

namespace Clean.Data.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        public readonly DataContext _context;

        public TaskRepository(DataContext context)
        {
            _context = context;
        }

        public Task GetById(int taskId)
        {
            return _context.Tasks.Find(t => t.ProjectId == taskId);
        }

        public List<Task> GetAll()
        {
            return _context.Tasks.ToList();
        }
    }
}
