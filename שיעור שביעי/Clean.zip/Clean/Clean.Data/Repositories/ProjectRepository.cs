﻿using Clean.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Clean.Core.Repositories;

namespace Clean.Data.Repositories
{
    public class ProjectRepository : IProjectRepository
    {
        public readonly DataContext _context;

        public ProjectRepository(DataContext context)
        {
            _context = context;
        }

        public Project Get(int id)
        {
            return _context.Projects.Find(p => p.Id == id);
        }
    }
}
