﻿using Clean.Core.Entities;

namespace Clean.Core.Services
{
    public interface IProjectService
    {
        Project Get(int id);
    }
}