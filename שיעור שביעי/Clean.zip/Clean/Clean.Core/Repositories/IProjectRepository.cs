﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clean.Core.Entities;

namespace Clean.Core.Repositories
{
    public interface IProjectRepository
    {
        Project Get(int id);
    }
}
