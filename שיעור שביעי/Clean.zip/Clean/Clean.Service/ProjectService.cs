﻿using Clean.Core.Entities;
using Clean.Core.Repositories;
using Clean.Core.Services;

namespace Clean.Service
{
    public class ProjectService : IProjectService
    {
        public readonly IProjectRepository _projectRepository;

        public ProjectService(IProjectRepository projectRepository)
        {
            _projectRepository = projectRepository;
        }

        public Project Get(int id)
        {
            // TODO: business logic

            return _projectRepository.Get(id);
        }
    }
}