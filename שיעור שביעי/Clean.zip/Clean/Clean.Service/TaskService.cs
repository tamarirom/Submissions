﻿using Clean.Core.Entities;
using Clean.Core.Repositories;
using Task = Clean.Core.Entities.Task;
using Clean.Core.Services;

namespace Clean.Service
{
    public class TaskService : ITaskService
    {
        public readonly ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        public Task GetById(int taskId)
        {
            //TODO business logic

            return _taskRepository.GetById(taskId);
        }

        public List<Task> GetAll()
        {
            //TODO business logic

            return _taskRepository.GetAll();
        }
    }
}
